let lastSentUrl = "";

chrome.webRequest.onSendHeaders.addListener(
  function(details) {
    const url = details.url.toLowerCase();
    
    // Sadece video stream dosyalarını hedefle. (Özellikle m3u8)
    if (url.includes(".m3u8") || url.includes(".mp4")) {
      
      // Eğer bir resim, script vb. mp4 kelimesi içeriyorsa filtrelemek için basit bir kontrol
      if (details.type !== "xmlhttprequest" && details.type !== "media" && details.type !== "other") {
          return;
      }
        
      // Aynı URL'yi arka arkaya defalarca göndermemek için kontrol
      if (lastSentUrl === details.url) {
        return;
      }
      lastSentUrl = details.url;
      
      let headersDict = {};
      if (details.requestHeaders) {
        for (let header of details.requestHeaders) {
          // yt-dlp standart header formatlarına daha uygun olması için
          headersDict[header.name] = header.value;
        }
      }
      
      console.log("Video bulundu, Sessiz'e gönderiliyor:", details.url);
      
      // Localhost'taki Python uygulamasına gönder
      fetch("http://localhost:5050/api/download", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          url: details.url,
          headers: headersDict
        })
      }).then(response => {
        console.log("Sessiz'e başarıyla gönderildi.");
      }).catch(err => {
        console.error("Gönderme hatası (Sessiz uygulaması açık mı?):", err);
      });
    }
  },
  { urls: ["<all_urls>"] },
  ["requestHeaders", "extraHeaders"]
);
